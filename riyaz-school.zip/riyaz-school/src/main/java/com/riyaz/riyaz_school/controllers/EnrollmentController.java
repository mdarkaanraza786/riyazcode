package com.riyaz.riyaz_school.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.Enrollment;
import com.riyaz.riyaz_school.repositories.ClassRepository;
import com.riyaz.riyaz_school.repositories.EnrollmentRepository;
import com.riyaz.riyaz_school.repositories.StudentRepository;

@Controller
@RequestMapping("/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ClassRepository classRepository;

    // Show all enrollments
    @GetMapping
    public String listEnrollments(Model model) {
        List<Enrollment> enrollments = enrollmentRepository.findAll();
        model.addAttribute("enrollments", enrollments);
        return "enrollments";  // renders enrollments.html
    }

    // Show form to add a new enrollment
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("enrollment", new Enrollment());

        // dropdown data
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("classes", classRepository.findAll());

        return "enrollment-form";  // renders enrollment-form.html
    }

    // Show form to edit an existing enrollment
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid enrollment Id: " + id));

        model.addAttribute("enrollment", enrollment);
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("classes", classRepository.findAll());

        return "enrollment-form";  // reuse same form
    }

    // Save enrollment (add or update)
    @PostMapping("/save")
    public String saveEnrollment(@ModelAttribute("enrollment") Enrollment enrollment) {
        enrollmentRepository.save(enrollment);
        return "redirect:/enrollments";
    }

    // Delete enrollment
    @GetMapping("/delete/{id}")
    public String deleteEnrollment(@PathVariable("id") Integer id) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid enrollment Id: " + id));
        enrollmentRepository.delete(enrollment);
        return "redirect:/enrollments";
    }
}
