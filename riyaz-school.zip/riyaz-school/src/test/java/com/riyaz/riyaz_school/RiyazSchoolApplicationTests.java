package com.riyaz.riyaz_school;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiyazSchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
