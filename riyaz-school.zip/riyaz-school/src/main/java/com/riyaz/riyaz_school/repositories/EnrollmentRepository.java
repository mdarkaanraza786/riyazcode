package com.riyaz.riyaz_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.riyaz.riyaz_school.models.Enrollment;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Integer> {}

