package com.riyaz.riyaz_school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiyazSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiyazSchoolApplication.class, args);
	}

}
