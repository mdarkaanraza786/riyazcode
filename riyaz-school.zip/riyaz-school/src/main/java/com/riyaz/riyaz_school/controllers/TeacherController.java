package com.riyaz.riyaz_school.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.Teacher;
import com.riyaz.riyaz_school.repositories.TeacherRepository;

@Controller
@RequestMapping("/teachers")
public class TeacherController {
    private final TeacherRepository teacherRepo;

    public TeacherController(TeacherRepository teacherRepo) {
        this.teacherRepo = teacherRepo;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("teachers", teacherRepo.findAll());
        return "teachers";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("teacher", new Teacher());
        return "teacher-form";
    }

   /*
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("teacher", teacherRepo.findById(id).orElseThrow());
        return "teacher-form";
    }
    */

    @PostMapping("/save")
    public String save(@ModelAttribute Teacher teacher) {
        teacherRepo.save(teacher);
        return "redirect:/teachers";
    }

    /*
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        teacherRepo.deleteById(id);
        return "redirect:/teachers";
    }
    */
}
