package com.riyaz.riyaz_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.riyaz.riyaz_school.models.ClassEntity;

public interface ClassRepository extends JpaRepository<ClassEntity, Integer> {}

