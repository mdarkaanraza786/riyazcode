package com.riyaz.riyaz_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.riyaz.riyaz_school.models.Subject;

public interface SubjectRepository extends JpaRepository<Subject, Integer> {}
