
create database companydb

use companydb

create table tbt_employee(
id int,
fname varchar(50),
lname varchar(50),
mobileno int,
mail varchar(50)
)





insert into companydb.tbt_employee(id,fname,lname,mobileno,mail)
values(101,'Arkaan','Raza',123456789,'mdarkaanraza786@gmail.com');

insert into companydb.tbt_employee(id,fname,lname,mobileno,mail)
values(102,'Riyaz','Alam',123456789,'mdalam786@gmail.com');

insert into companydb.tbt_employee(id,fname,lname,mobileno,mail)
values(103,'Arham','Raza',123456789,'mdarkaanraz786@gmail.com');

insert into companydb.tbt_employee(id,fname,lname,mobileno,mail)
values(104,'Manzar','Raza',999999,'alam786@gmail.com');

insert into companydb.tbt_employee(id,fname,lname,mobileno,mail)
values(105,'Aaira','Fatima',888888,'mdarkaanraza786@gmail.com');

