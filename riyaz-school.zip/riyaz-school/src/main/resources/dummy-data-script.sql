USE schoolDB;

-- =======================
-- 1. TEACHERS
-- =======================
INSERT INTO teachers (first_name, last_name, email, phone, specialization, hire_date) VALUES
('Alice', 'Johnson', 'alice.johnson@school.com', '9876543210', 'Mathematics', '2020-06-15'),
('Bob', 'Smith', 'bob.smith@school.com', '9123456780', 'Science', '2019-03-01'),
('Carol', 'Williams', 'carol.williams@school.com', '9988776655', 'English', '2021-01-10'),
('David', 'Brown', 'david.brown@school.com', '9898989898', 'Computer Science', '2022-09-01');

-- =======================
-- 2. SUBJECTS
-- =======================
INSERT INTO subjects (subject_name, description) VALUES
('Mathematics', 'Study of numbers, equations, functions, and geometry.'),
('Physics', 'Matter, energy, motion, and fundamental laws of nature.'),
('Biology', 'Living organisms, ecosystems, and human anatomy.'),
('English', 'Grammar, literature, writing, and communication skills.'),
('Computer Science', 'Programming, algorithms, and technology concepts.');

-- =======================
-- 3. CLASSES
-- (links teachers with subjects)
-- =======================
INSERT INTO classes (class_name, teacher_id, subject_id, schedule) VALUES
('Math 10A', 1, 1, 'Mon/Wed/Fri 09:00-10:00'),
('Physics 10B', 2, 2, 'Tue/Thu 10:00-11:30'),
('English 9A', 3, 4, 'Mon/Wed 11:00-12:00'),
('Biology 11A', 2, 3, 'Tue/Thu 13:00-14:30'),
('CS 12A', 4, 5, 'Fri 14:00-16:00');

-- =======================
-- 4. STUDENTS
-- =======================
INSERT INTO students (first_name, last_name, dob, gender, email, phone, address, enrollment_date) VALUES
('John', 'Doe', '2006-02-10', 'Male', 'john.doe@student.com', '9876543211', '123 Main St', '2022-06-01'),
('Emily', 'Clark', '2007-07-25', 'Female', 'emily.clark@student.com', '9876543222', '456 Oak Ave', '2022-06-01'),
('Michael', 'Brown', '2005-11-15', 'Male', 'michael.brown@student.com', '9876543233', '789 Pine Rd', '2022-06-01'),
('Sophia', 'Davis', '2006-03-12', 'Female', 'sophia.davis@student.com', '9876543244', '101 Elm St', '2022-06-01'),
('Liam', 'Wilson', '2007-09-20', 'Male', 'liam.wilson@student.com', '9876543255', '202 Cedar Ln', '2022-06-01');

-- =======================
-- 5. ENROLLMENTS
-- (students joining classes)
-- =======================
INSERT INTO enrollments (student_id, class_id, enrollment_date) VALUES
(1, 1, '2022-06-05'),
(2, 1, '2022-06-05'),
(3, 2, '2022-06-06'),
(4, 3, '2022-06-06'),
(5, 4, '2022-06-07'),
(1, 5, '2022-06-08');

-- =======================
-- 6. GRADES
-- (performance records)
-- =======================
INSERT INTO grades (student_id, class_id, grade, exam_date) VALUES
(1, 1, 'A', '2023-03-15'),
(2, 1, 'B+', '2023-03-15'),
(3, 2, 'A-', '2023-03-16'),
(4, 3, 'B', '2023-03-17'),
(5, 4, 'A', '2023-03-18'),
(1, 5, 'A+', '2023-03-19');
