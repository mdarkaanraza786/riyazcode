package com.riyaz.riyaz_school.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.Grade;
import com.riyaz.riyaz_school.repositories.ClassRepository;
import com.riyaz.riyaz_school.repositories.GradeRepository;
import com.riyaz.riyaz_school.repositories.StudentRepository;

@Controller
@RequestMapping("/grades")
public class GradeController {

    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ClassRepository classRepository;

    // Show all grades
    @GetMapping
    public String listGrades(Model model) {
        List<Grade> grades = gradeRepository.findAll();
        model.addAttribute("grades", grades);
        return "grades";  // renders grades.html
    }

    // Show form to add a new grade
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("grade", new Grade());

        // dropdowns
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("classes", classRepository.findAll());

        return "grade-form";  // renders grade-form.html
    }

    // Show form to edit an existing grade
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        Grade grade = gradeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid grade Id: " + id));

        model.addAttribute("grade", grade);
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("classes", classRepository.findAll());

        return "grade-form";  // reuse same form
    }

    // Save grade (add or update)
    @PostMapping("/save")
    public String saveGrade(@ModelAttribute("grade") Grade grade) {
        gradeRepository.save(grade);
        return "redirect:/grades";
    }

    // Delete grade
    @GetMapping("/delete/{id}")
    public String deleteGrade(@PathVariable("id") Integer id) {
        Grade grade = gradeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid grade Id: " + id));
        gradeRepository.delete(grade);
        return "redirect:/grades";
    }
}
