package com.riyaz.riyaz_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.riyaz.riyaz_school.models.Grade;

public interface GradeRepository extends JpaRepository<Grade, Integer> {}

