package com.riyaz.riyaz_school.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.Subject;
import com.riyaz.riyaz_school.repositories.SubjectRepository;

@Controller
@RequestMapping("/subjects")
public class SubjectController {

    @Autowired
    private SubjectRepository subjectRepository;

    // Show all subjects
    @GetMapping
    public String listSubjects(Model model) {
        List<Subject> subjects = subjectRepository.findAll();
        model.addAttribute("subjects", subjects);
        return "subjects";  // renders subjects.html
    }

    // Show form to add a new subject
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("subject", new Subject());
        return "subject-form";  // renders subject-form.html
    }

    // Show form to edit an existing subject
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        Subject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid subject Id: " + id));
        model.addAttribute("subject", subject);
        return "subject-form";  // reuses the same form
    }

    // Save subject (handles both add & update)
    @PostMapping("/save")
    public String saveSubject(@ModelAttribute("subject") Subject subject) {
        subjectRepository.save(subject);
        return "redirect:/subjects";
    }

    // Delete subject
    @GetMapping("/delete/{id}")
    public String deleteSubject(@PathVariable("id") Integer id) {
        Subject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid subject Id: " + id));
        subjectRepository.delete(subject);
        return "redirect:/subjects";
    }
}
