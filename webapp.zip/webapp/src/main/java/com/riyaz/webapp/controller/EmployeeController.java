package com.riyaz.webapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.riyaz.webapp.repositories.EmployeeRepository;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	
	@GetMapping({"","employee/all"})
	public String getEmployees(Model model)
	{
		var employees= employeeRepo.findAll();
		model.addAttribute("employees",employees);
		return "employee/emphome";
	}

	
	@GetMapping({"","/registration"})
	public String registration()
	{		
		return "employee/registration";
	}
}
