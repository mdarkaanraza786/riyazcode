package com.riyaz.riyaz_school.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.ClassEntity;
import com.riyaz.riyaz_school.repositories.ClassRepository;
import com.riyaz.riyaz_school.repositories.SubjectRepository;
import com.riyaz.riyaz_school.repositories.TeacherRepository;

@Controller
@RequestMapping("/classes")
public class ClassController {

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private SubjectRepository subjectRepository;

    // Show all classes
    @GetMapping
    public String listClasses(Model model) {
        List<ClassEntity> classes = classRepository.findAll();
        model.addAttribute("classes", classes);
        return "classes";  // renders classes.html
    }

    // Show form to add a new class
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("classEntity", new ClassEntity());

        // load teachers and subjects for dropdowns
        model.addAttribute("teachers", teacherRepository.findAll());
        model.addAttribute("subjects", subjectRepository.findAll());

        return "class-form";  // renders class-form.html
    }

    // Show form to edit an existing class
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        ClassEntity classEntity = classRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid class Id: " + id));

        model.addAttribute("classEntity", classEntity);
        model.addAttribute("teachers", teacherRepository.findAll());
        model.addAttribute("subjects", subjectRepository.findAll());

        return "class-form";  // reuses same form
    }

    // Save class (handles both add & update)
    @PostMapping("/save")
    public String saveClass(@ModelAttribute("classEntity") ClassEntity classEntity) {
        classRepository.save(classEntity);
        return "redirect:/classes";
    }

    // Delete class
    @GetMapping("/delete/{id}")
    public String deleteClass(@PathVariable("id") Integer id) {
        ClassEntity classEntity = classRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid class Id: " + id));
        classRepository.delete(classEntity);
        return "redirect:/classes";
    }
}
