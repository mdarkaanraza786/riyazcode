package com.riyaz.riyaz_school.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.riyaz.riyaz_school.models.Student;
import com.riyaz.riyaz_school.repositories.StudentRepository;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final StudentRepository studentRepo;

    public StudentController(StudentRepository studentRepo) {
        this.studentRepo = studentRepo;
    }

    @GetMapping
    public String listStudents(Model model) {
        model.addAttribute("students", studentRepo.findAll());
        System.out.println("method called.......listStudents");
        return "students";
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("student", new Student());
        return "student-form";
    }

  /*  @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("student", studentRepo.findById(id).orElseThrow());
        return "student-form";
    }
    */

    @PostMapping("/save")
    public String save(@ModelAttribute Student student) {
        studentRepo.save(student);
        return "redirect:/students";
    }

   /*
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        studentRepo.deleteById(id);
        return "redirect:/students";
    }  */
}
